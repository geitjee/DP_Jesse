package P2;

import java.sql.Date;

public class Reiziger {

    private int id;
    private String voorletters;
    private String tussenvoegsel;
    private String achternaam;
    private Date geboortedatum;
    public Reiziger(){ }

    public Reiziger(int id,String v, String t, String a, Date gb){
        this.id = id;
        this.voorletters = v;
        this.tussenvoegsel = t;
        this.achternaam = a;
        this.geboortedatum = gb;
    }

    public int getId(){ return this.id; }
    public void setId(int id){ this.id = id; }

    public String getVoorletters(){return this.voorletters;}
    public void setVoorletters(String voorletters){ this.voorletters = voorletters;}

    public String getTussenvoegsel(){return this.tussenvoegsel;}
    public void setTussenvoegsel(String tussenvoegsel){ this.tussenvoegsel = tussenvoegsel;}

    public String getAchternaam(){return this.achternaam;}
    public void setAchternaam(String achternaam){this.achternaam = achternaam;}

    public Date getGeboortedatum(){return this.geboortedatum;}
    public void setGeboortedatum(Date geboortedatum){this.geboortedatum = geboortedatum;}

    public String getNaam(){
        if (this.tussenvoegsel == null || this.tussenvoegsel == ""){
            return this.voorletters + " " + this.achternaam;
        }
        else{
            return this.voorletters + " " + this.tussenvoegsel + " " + this.achternaam;
        }
    }

    public String toString() {
        return "#" + id + ": " + getNaam() + " (" + geboortedatum + ")";
    }
}
